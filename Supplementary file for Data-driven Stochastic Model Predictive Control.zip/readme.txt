This is the supporting files for the paper, which include the following contents:

1.The wind_speed_profiles folder includes the wind speed and wind speed prediction error historical data for various wind turbines.
2.The Parameters_of_system&controller.docx file provides the parameters of the wind farm and the controller used for simulation.
3.The result_of_GMM_estimation.mat is a MATLAB data file, containing the GMM parameters obtained after fitting the historical wind speed prediction errors using GMM.
4.The verification_of_formula_in_appendix.xlsx provides the results of the numerical experiments used to verify the correctness of the formulas in the appendix.